'use strict';

/**
 * MV3 deadline proximity checks via chrome.alarms (week/month end reminders).
 */

const ALARM_NAME = 'deadline-proximity-check';

const PROD_CHECK_INTERVAL_MINUTES = 240;
const DEV_CHECK_INTERVAL_MINUTES = 1;

const WEEK_END_DAY = 6;
const WEEK_ALERT_WITHIN_DAYS = 2;
const MONTH_ALERT_WITHIN_DAYS = 7;

const STORAGE = {
  hasNotifiedToday: 'deadline_hasNotifiedToday',
  notifiedOnDate: 'deadline_notifiedOnDate',
  weekWindowActive: 'deadline_weekWindowActive',
  monthWindowActive: 'deadline_monthWindowActive'
};

function isDevBuild() {
  return !('update_url' in chrome.runtime.getManifest());
}

function getCheckIntervalMinutes() {
  return isDevBuild() ? DEV_CHECK_INTERVAL_MINUTES : PROD_CHECK_INTERVAL_MINUTES;
}

function todayKey() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function daysUntilSaturday(date = new Date()) {
  const weekday = date.getDay();
  return (WEEK_END_DAY - weekday + 7) % 7;
}

function daysUntilMonthEnd(date = new Date()) {
  const year = date.getFullYear();
  const month = date.getMonth();
  const lastDayOfMonth = new Date(year, month + 1, 0).getDate();
  return lastDayOfMonth - date.getDate();
}

function isWithinSpan(daysUntil, withinDays) {
  return daysUntil >= 0 && daysUntil <= withinDays;
}

async function hasNotifiedToday() {
  const today = todayKey();
  const data = await chrome.storage.local.get([
    STORAGE.hasNotifiedToday,
    STORAGE.notifiedOnDate
  ]);

  if (data[STORAGE.notifiedOnDate] !== today) {
    await chrome.storage.local.set({
      [STORAGE.notifiedOnDate]: today,
      [STORAGE.hasNotifiedToday]: false
    });
    return false;
  }

  return data[STORAGE.hasNotifiedToday] === true;
}

async function setHasNotifiedToday() {
  await chrome.storage.local.set({
    [STORAGE.notifiedOnDate]: todayKey(),
    [STORAGE.hasNotifiedToday]: true
  });
}

async function cleanupStorage(weekDaysLeft, monthDaysLeft) {
  const toRemove = [];

  if (!isWithinSpan(weekDaysLeft, WEEK_ALERT_WITHIN_DAYS)) {
    toRemove.push(STORAGE.weekWindowActive);
  }
  if (!isWithinSpan(monthDaysLeft, MONTH_ALERT_WITHIN_DAYS)) {
    toRemove.push(STORAGE.monthWindowActive);
  }

  if (toRemove.length) {
    await chrome.storage.local.remove(toRemove);
  }

  if (toRemove.length === 2) {
    const data = await chrome.storage.local.get([
      STORAGE.notifiedOnDate,
      STORAGE.hasNotifiedToday
    ]);
    if (data[STORAGE.notifiedOnDate] && data[STORAGE.notifiedOnDate] < todayKey()) {
      await chrome.storage.local.remove([
        STORAGE.notifiedOnDate,
        STORAGE.hasNotifiedToday
      ]);
    }
  }
}

async function markActiveWindows(weekAlert, monthAlert) {
  const patch = {};
  if (weekAlert) patch[STORAGE.weekWindowActive] = todayKey();
  if (monthAlert) patch[STORAGE.monthWindowActive] = todayKey();
  if (Object.keys(patch).length) {
    await chrome.storage.local.set(patch);
  }
}

function notificationIconUrl() {
  return chrome.runtime.getURL('icons/icon-128.png');
}

function buildNotificationContent(weekDaysLeft, monthDaysLeft) {
  const lines = [];

  if (isWithinSpan(weekDaysLeft, WEEK_ALERT_WITHIN_DAYS)) {
    if (weekDaysLeft === 0) {
      lines.push('This week ends today (Saturday).');
    } else {
      lines.push(`Week ends in ${weekDaysLeft} day(s) (Saturday).`);
    }
  }

  if (isWithinSpan(monthDaysLeft, MONTH_ALERT_WITHIN_DAYS)) {
    if (monthDaysLeft === 0) {
      lines.push('The calendar month ends today.');
    } else {
      lines.push(`Month ends in ${monthDaysLeft} day(s).`);
    }
  }

  return {
    title: 'Deadline reminder',
    message: lines.join(' ')
  };
}

async function showNotification(title, message) {
  await chrome.notifications.create('deadline-reminder-daily', {
    type: 'basic',
    iconUrl: notificationIconUrl(),
    title,
    message,
    priority: 1
  });
}

async function runDeadlineCheck() {
  const now = new Date();
  const weekDaysLeft = daysUntilSaturday(now);
  const monthDaysLeft = daysUntilMonthEnd(now);

  const weekAlert = isWithinSpan(weekDaysLeft, WEEK_ALERT_WITHIN_DAYS);
  const monthAlert = isWithinSpan(monthDaysLeft, MONTH_ALERT_WITHIN_DAYS);

  await cleanupStorage(weekDaysLeft, monthDaysLeft);

  if (!weekAlert && !monthAlert) {
    return;
  }

  await markActiveWindows(weekAlert, monthAlert);

  if (await hasNotifiedToday()) {
    return;
  }

  const { title, message } = buildNotificationContent(weekDaysLeft, monthDaysLeft);
  await showNotification(title, message);
  await setHasNotifiedToday();
}

async function ensureDeadlineAlarm() {
  const periodInMinutes = getCheckIntervalMinutes();
  const existing = await chrome.alarms.get(ALARM_NAME);

  if (existing?.periodInMinutes === periodInMinutes) {
    return;
  }

  await chrome.alarms.clear(ALARM_NAME);
  await chrome.alarms.create(ALARM_NAME, { periodInMinutes });

  console.info(
    `[deadline-reminder] alarm every ${periodInMinutes} min (${isDevBuild() ? 'dev' : 'prod'})`
  );
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name !== ALARM_NAME) {
    return;
  }
  runDeadlineCheck().catch((err) => {
    console.error('[deadline-reminder] check failed:', err);
  });
});

self.initDeadlineReminder = async function initDeadlineReminder() {
  await ensureDeadlineAlarm();
  await runDeadlineCheck();
};
